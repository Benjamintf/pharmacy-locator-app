const { Pool } = require('pg');

const ssl = String(process.env.DB_SSL).toLowerCase() === 'true' ? { rejectUnauthorized: false } : false;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});
pool.on('error', (err) => console.error('Unexpected PostgreSQL pool error', err));
module.exports = pool;
