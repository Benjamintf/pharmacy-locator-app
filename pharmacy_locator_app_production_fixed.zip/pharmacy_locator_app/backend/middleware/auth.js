const jwt=require('jsonwebtoken');
function requireAuth(req,res,next){const h=req.header('authorization')||'';if(!h.startsWith('Bearer '))return res.status(401).json({error:'Authentication required.'});try{req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET);next();}catch(_){return res.status(401).json({error:'Invalid or expired token.'});}}
function requireOwner(req,res,next){if(!['pharmacy_owner','admin'].includes(req.user?.role))return res.status(403).json({error:'Pharmacy owner account required.'});next();}
module.exports={requireAuth,requireOwner};