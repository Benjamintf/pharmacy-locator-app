const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
module.exports = function requireOwner(req, res, next) {
  const userId = req.header('x-user-id');
  if (!userId || !UUID_RE.test(userId)) return res.status(401).json({ error: 'A valid x-user-id header is required.' });
  req.userId = userId;
  next();
};
