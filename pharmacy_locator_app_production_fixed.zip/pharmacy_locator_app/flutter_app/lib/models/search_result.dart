class SearchResult {
  final String medicineName, pharmacyName, phone, address;
  final double price; final int quantity; final bool available;
  SearchResult({required this.medicineName,required this.pharmacyName,required this.phone,required this.address,required this.price,required this.quantity,required this.available});
  factory SearchResult.fromJson(Map<String,dynamic> j)=>SearchResult(
    medicineName:(j['brand_name']??'').toString(), pharmacyName:(j['pharmacy_name']??'').toString(),
    phone:(j['phone_number']??'').toString(), address:(j['address_text']??'').toString(),
    price:(j['price'] as num?)?.toDouble()??0, quantity:(j['quantity'] as num?)?.toInt()??0, available:j['is_available']==true);
}
