import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/app_config.dart';
import '../models/search_result.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class ApiService {
  final http.Client _client;
  ApiService({http.Client? client}) : _client = client ?? http.Client();

  String _message(http.Response response) {
    try {
      final data = jsonDecode(response.body);
      if (data is Map<String, dynamic>) {
        return (data['error'] ?? data['message'] ?? 'Request failed (${response.statusCode})').toString();
      }
    } catch (_) {}
    return 'Request failed (${response.statusCode})';
  }

  Future<Map<String, String>> _headers({bool auth = false}) async {
    final headers = {'Content-Type': 'application/json', 'Accept': 'application/json'};
    if (auth) {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');
      if (token == null || token.isEmpty) throw ApiException('Please log in first.');
      headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  Future<http.Response> _safe(Future<http.Response> request) async {
    try {
      return await request.timeout(const Duration(seconds: 30));
    } on TimeoutException {
      throw ApiException('The server took too long to respond. Please try again.');
    } on SocketException {
      throw ApiException('Cannot reach the server. Check your internet connection and backend URL.');
    } on http.ClientException {
      throw ApiException('Cannot connect to the backend server.');
    } on StateError catch (e) {
      throw ApiException(e.message);
    }
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final base = AppConfig.apiBaseUrl;
    final response = await _safe(_client.post(Uri.parse('$base/auth/login'), headers: await _headers(), body: jsonEncode({'email': email, 'password': password})));
    if (response.statusCode != 200) throw ApiException(_message(response));
    return Map<String, dynamic>.from(jsonDecode(response.body));
  }

  Future<Map<String, dynamic>> register(Map<String, dynamic> body) async {
    final base = AppConfig.apiBaseUrl;
    final response = await _safe(_client.post(Uri.parse('$base/auth/register'), headers: await _headers(), body: jsonEncode(body)));
    if (response.statusCode != 201) throw ApiException(_message(response));
    return Map<String, dynamic>.from(jsonDecode(response.body));
  }

  Future<void> saveSession(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    final user = Map<String, dynamic>.from(data['user'] as Map);
    await prefs.setString('auth_token', data['token'].toString());
    await prefs.setString('user_id', user['id'].toString());
    await prefs.setString('user_role', user['role'].toString());
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('user_id');
    await prefs.remove('user_role');
  }

  Future<List<SearchResult>> search(String query) async {
    final base = AppConfig.apiBaseUrl;
    final uri = Uri.parse('$base/medicines/search').replace(queryParameters: {'query': query});
    final response = await _safe(_client.get(uri));
    if (response.statusCode != 200) throw ApiException(_message(response));
    final data = jsonDecode(response.body) as List<dynamic>;
    return data.map((e) => SearchResult.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<Map<String, dynamic>> addPharmacy(Map<String, dynamic> body) async {
    final base = AppConfig.apiBaseUrl;
    final response = await _safe(_client.post(Uri.parse('$base/pharmacies/add'), headers: await _headers(auth: true), body: jsonEncode(body)));
    if (response.statusCode != 201) throw ApiException(_message(response));
    return Map<String, dynamic>.from(jsonDecode(response.body));
  }
}
