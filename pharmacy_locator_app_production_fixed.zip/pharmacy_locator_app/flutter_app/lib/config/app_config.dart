class AppConfig {
  static const String _configured = String.fromEnvironment('API_BASE_URL');

  static String get apiBaseUrl {
    final value = _configured.trim();
    if (value.isEmpty) {
      throw StateError(
        'API server is not configured. Build the app with '
        '--dart-define=API_BASE_URL=https://YOUR-SERVER/api',
      );
    }
    return value.endsWith('/') ? value.substring(0, value.length - 1) : value;
  }
}
