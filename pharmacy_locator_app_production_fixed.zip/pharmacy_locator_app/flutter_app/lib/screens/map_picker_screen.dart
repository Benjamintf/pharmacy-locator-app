import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import '../l10n/app_strings.dart';
class MapPickerScreen extends StatefulWidget { const MapPickerScreen({super.key}); @override State<MapPickerScreen> createState()=>_MapPickerScreenState(); }
class _MapPickerScreenState extends State<MapPickerScreen>{
  final _controller=MapController(); LatLng? selected; LatLng center=const LatLng(9.03,38.74);
  @override void initState(){super.initState();_locate();}
  Future<void> _locate() async { try { var p=await Geolocator.checkPermission(); if(p==LocationPermission.denied)p=await Geolocator.requestPermission(); if(p==LocationPermission.always||p==LocationPermission.whileInUse){final x=await Geolocator.getCurrentPosition(); if(mounted){setState(()=>center=LatLng(x.latitude,x.longitude));_controller.move(center,15);}} } catch(_){} }
  @override Widget build(BuildContext context){final s=AppStrings(Localizations.localeOf(context));return Scaffold(appBar:AppBar(title:Text(s.pickMap)),body:Stack(children:[FlutterMap(mapController:_controller,options:MapOptions(initialCenter:center,initialZoom:13,onTap:(_,p)=>setState(()=>selected=p)),children:[TileLayer(urlTemplate:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',userAgentPackageName:'com.example.pharmacy_locator_app'),if(selected!=null)MarkerLayer(markers:[Marker(point:selected!,width:50,height:50,child:const Icon(Icons.location_pin,size:48,color:Colors.red))]),RichAttributionWidget(attributions:[TextSourceAttribution('OpenStreetMap contributors')])]),Positioned(left:16,right:16,bottom:24,child:FilledButton.icon(onPressed:selected==null?null:()=>Navigator.pop(context,selected),icon:const Icon(Icons.check),label:Text(selected==null?s.selectPoint:s.confirm))) ]));}
}
