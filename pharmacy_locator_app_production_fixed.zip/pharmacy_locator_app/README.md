# Pharmacy Locator

Flutter + Express + PostgreSQL pharmacy locator with JWT authentication, pharmacy-owner authorization, medicine search, English/Amharic UI, and OpenStreetMap location picking.

## Deploy backend on Render

This repository includes `render.yaml`. Create a Render Blueprint from this repository. It creates the Node API and PostgreSQL database, generates `JWT_SECRET`, wires `DATABASE_URL`, creates the schema on startup, and exposes `/health`.

After deployment, open `https://YOUR-RENDER-SERVICE.onrender.com/health`. It should return `{"status":"ok"}`.

## Build Android APK on GitHub

In GitHub: Settings → Secrets and variables → Actions → New repository secret.

Name: `API_BASE_URL`

Value: `https://YOUR-RENDER-SERVICE.onrender.com/api`

Then run **Actions → Build Pharmacy Locator APK → Run workflow**. Download the `pharmacy-locator-apk` artifact and install `app-release.apk` on Android.

The workflow refuses to build if the production API URL is missing, preventing an APK that accidentally points to emulator-only `10.0.2.2`.
