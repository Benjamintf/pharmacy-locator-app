# Pharmacy Locator App v2

Complete Flutter + Express + PostgreSQL app with JWT login/sign-up, user/pharmacy-owner roles, authenticated pharmacy creation, medicine inventory/search, English/Amharic UI, and OpenStreetMap picker.

## Backend
1. Copy `backend/.env.example` to `.env`.
2. Set `DATABASE_URL` and a long random `JWT_SECRET`.
3. `cd backend && npm install && npm run db:schema && npm start`.

## Flutter
The GitHub Action generates the Android platform, adds INTERNET permission and local-development cleartext support, analyzes, builds, and uploads the APK. Add repository secret `API_BASE_URL`. It must include `/api`, for example `https://api.example.com/api`.

For a physical phone using a development computer, use the computer LAN address such as `http://192.168.1.20:3000/api`; `10.0.2.2` works only from the Android emulator. For production use HTTPS.

Run locally with `flutter create . --platforms=android`, `flutter pub get`, then `flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000/api`.

OpenStreetMap tiles use `https://tile.openstreetmap.org/{z}/{x}/{y}.png`. Pharmacy ownership is always derived from the verified JWT, never from a client-supplied owner ID.
