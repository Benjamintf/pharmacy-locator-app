const express = require('express');
const pool = require('../config/db');
const requireOwner = require('../middleware/owner');
const router = express.Router();
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

router.post('/add', requireOwner, async (req, res) => {
  const client = await pool.connect();
  try {
    const { pharmacyId, medicineName, genericName = null, description = null, price, stock } = req.body;
    const p = Number(price), qty = Number(stock);
    if (!UUID_RE.test(String(pharmacyId || '')) || !medicineName?.trim()) return res.status(400).json({ error: 'Valid pharmacyId and medicineName are required.' });
    if (!Number.isFinite(p) || p < 0 || !Number.isInteger(qty) || qty < 0) return res.status(400).json({ error: 'price must be >= 0 and stock must be a non-negative integer.' });
    await client.query('BEGIN');
    const pharmacy = await client.query('SELECT id FROM pharmacies WHERE id=$1 AND owner_id=$2', [pharmacyId, req.userId]);
    if (!pharmacy.rowCount) { await client.query('ROLLBACK'); return res.status(403).json({ error: 'Pharmacy not found or not owned by this user.' }); }
    let med = await client.query('SELECT * FROM medicines WHERE lower(brand_name)=lower($1) ORDER BY created_at LIMIT 1', [medicineName.trim()]);
    if (!med.rowCount) med = await client.query('INSERT INTO medicines (brand_name,generic_name,description) VALUES ($1,$2,$3) RETURNING *', [medicineName.trim(), genericName?.trim() || null, description?.trim() || null]);
    const inv = await client.query(`INSERT INTO pharmacy_inventory (pharmacy_id,medicine_id,price,quantity,is_available,updated_at)
      VALUES ($1,$2,$3,$4,$4>0,now()) ON CONFLICT (pharmacy_id,medicine_id) DO UPDATE
      SET price=EXCLUDED.price,quantity=EXCLUDED.quantity,is_available=EXCLUDED.quantity>0,updated_at=now() RETURNING *`, [pharmacyId, med.rows[0].id, p, qty]);
    await client.query('COMMIT');
    return res.status(201).json({ medicine: med.rows[0], inventory: inv.rows[0] });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {}); console.error('POST /api/medicines/add', err);
    return res.status(500).json({ error: 'Unable to add medicine inventory.' });
  } finally { client.release(); }
});

router.get('/search', async (req, res) => {
  try {
    const query = String(req.query.query || '').trim();
    if (!query) return res.status(400).json({ error: 'query is required.' });
    const pattern = `%${query}%`;
    const sql = `SELECT DISTINCT ON (m.id,p.id)
      m.id AS medicine_id,m.brand_name,m.generic_name,m.description,
      p.id AS pharmacy_id,p.name AS pharmacy_name,p.phone_number,p.address_text,p.latitude,p.longitude,p.is_open_24_7,p.operating_hours,
      COALESCE(pi.price,0)::float8 AS price,COALESCE(pi.quantity,0)::int AS quantity,COALESCE(pi.is_available,false) AS is_available,
      pi.updated_at
      FROM medicines m
      LEFT JOIN pharmacy_inventory pi ON pi.medicine_id=m.id
      LEFT JOIN pharmacies p ON p.id=pi.pharmacy_id
      WHERE m.brand_name ILIKE $1 OR COALESCE(m.generic_name,'') ILIKE $1 OR COALESCE(p.name,'') ILIKE $1
         OR COALESCE(p.phone_number,'') ILIKE $1 OR COALESCE(p.address_text,'') ILIKE $1
      ORDER BY m.id,p.id,COALESCE(pi.is_available,false) DESC,pi.updated_at DESC NULLS LAST`;
    const result = await pool.query(sql, [pattern]);
    return res.json(result.rows);
  } catch (err) { console.error('GET /api/medicines/search', err); return res.status(500).json({ error: 'Search failed.' }); }
});

router.get('/:pharmacyId', async (req, res) => {
  try {
    if (!UUID_RE.test(req.params.pharmacyId)) return res.status(400).json({ error: 'Invalid pharmacy ID.' });
    const result = await pool.query(`SELECT pi.id,m.id AS medicine_id,m.brand_name,m.generic_name,m.description,
      pi.price::float8 AS price,pi.quantity,pi.is_available,pi.updated_at FROM pharmacy_inventory pi
      JOIN medicines m ON m.id=pi.medicine_id WHERE pi.pharmacy_id=$1 ORDER BY m.brand_name`, [req.params.pharmacyId]);
    return res.json(result.rows);
  } catch (err) { console.error('GET /api/medicines/:pharmacyId', err); return res.status(500).json({ error: 'Unable to load inventory.' }); }
});
module.exports = router;
