const express = require('express');
const pool = require('../config/db');
const requireOwner = require('../middleware/owner');
const router = express.Router();
const PHONE_RE = /^\+?[0-9][0-9\s().-]{6,24}$/;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

router.post('/add', requireOwner, async (req, res) => {
  try {
    const { name, phoneNumber, addressText, latitude, longitude, operatingHours = {}, isOpen24_7 = false } = req.body;
    const lat = Number(latitude), lng = Number(longitude);
    if (!name?.trim() || !addressText?.trim()) return res.status(400).json({ error: 'name and addressText are required.' });
    if (!PHONE_RE.test(String(phoneNumber || ''))) return res.status(400).json({ error: 'Invalid phone number.' });
    if (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lng) || lng < -180 || lng > 180) return res.status(400).json({ error: 'Invalid coordinates.' });
    if (typeof operatingHours !== 'object' || Array.isArray(operatingHours)) return res.status(400).json({ error: 'operatingHours must be a JSON object.' });
    if (!UUID_RE.test(req.userId)) return res.status(401).json({ error: 'Invalid owner identity.' });
    const owner = await pool.query("SELECT id FROM users WHERE id=$1 AND role IN ('pharmacy_owner','admin')", [req.userId]);
    if (!owner.rowCount) return res.status(403).json({ error: 'User is not an authorized pharmacy owner.' });
    const q = `INSERT INTO pharmacies (owner_id,name,phone_number,address_text,latitude,longitude,operating_hours,is_open_24_7)
      VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8) RETURNING *`;
    const result = await pool.query(q, [req.userId, name.trim(), phoneNumber.trim(), addressText.trim(), lat, lng, JSON.stringify(operatingHours), Boolean(isOpen24_7)]);
    return res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('POST /api/pharmacies/add', err);
    return res.status(500).json({ error: 'Unable to create pharmacy.' });
  }
});
module.exports = router;
