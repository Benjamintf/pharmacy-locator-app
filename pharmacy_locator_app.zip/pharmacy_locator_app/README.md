# Pharmacy Locator App

A complete Flutter + Express + PostgreSQL implementation for pharmacy registration, map pinning, medicine inventory, and medicine/pharmacy/location/phone search.

## 1. PostgreSQL

Create a database, enable the extensions, and apply the schema:

```bash
cd backend
cp .env.example .env
# Edit .env with your real PostgreSQL connection string and allowed origins.
npm install
npm run db:schema
```

The API intentionally requires an existing `pharmacy_owner` user for write operations. This avoids insecure anonymous ownership. Create one with a real bcrypt/Argon2 password hash from your identity/authentication service; the included API does not implement authentication because authentication endpoints were outside the requested specification. Use that user's UUID as `OWNER_USER_ID` for the Flutter owner workflow. Never store a plaintext password in `password_hash`.

Example SQL after obtaining a secure hash:

```sql
INSERT INTO users(full_name,email,phone,role,password_hash)
VALUES ('Pharmacy Owner','owner@example.com','+251911000000','pharmacy_owner','$2b$12$REPLACE_WITH_A_REAL_SECURE_HASH')
RETURNING id;
```

## 2. Backend environment

`backend/.env`:

```env
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/pharmacy_locator
PORT=3000
CORS_ORIGINS=http://localhost:3000,http://localhost:8080
DB_SSL=false
```

Run:

```bash
cd backend
npm install
npm start
```

The server listens on `0.0.0.0`, so a phone on the same LAN can connect. Allow TCP port 3000 through your firewall. For cloud deployment, use HTTPS behind a reverse proxy/load balancer and set `DB_SSL=true` when your managed PostgreSQL provider requires TLS. `CORS_ORIGINS` is comma-separated. Native Android/iOS HTTP clients are not browser-CORS constrained, but keeping a restrictive CORS policy protects web clients and future Flutter Web deployments.

## 3. Flutter

This archive contains the app source. Generate platform folders once with your installed Flutter SDK:

```bash
cd flutter_app
flutter create . --platforms=android,ios
flutter pub get
```

Android emulator:

```bash
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000/api --dart-define=OWNER_USER_ID=YOUR_OWNER_UUID
```

Physical phone on the same Wi-Fi: replace `10.0.2.2` with the computer's LAN IP, for example `192.168.1.20`. iOS Simulator can normally use `http://127.0.0.1:3000/api`. Production should use an HTTPS API URL.

For Android local HTTP development, if Android blocks cleartext traffic, set `android:usesCleartextTraffic="true"` in the `<application>` element of `android/app/src/main/AndroidManifest.xml`. Do not use cleartext HTTP in production.

## API

- `POST /api/pharmacies/add` requires `x-user-id` header for a `pharmacy_owner` or `admin`.
- `POST /api/medicines/add` requires the same owner header and verifies pharmacy ownership.
- `GET /api/medicines/search?query=...` is public.
- `GET /api/medicines/:pharmacyId` is public.
- `GET /health` is a deployment health check.

## Architecture

Flutter UI -> `ApiService` -> REST/JSON -> Express routes -> `pg` connection pool -> PostgreSQL. `pharmacy_inventory` is the normalized many-to-many relation between pharmacies and medicines. PostgreSQL `pg_trgm` GIN indexes accelerate fuzzy `ILIKE` searches. Foreign keys cascade inventory/pharmacy cleanup. The unique `(pharmacy_id, medicine_id)` constraint supports atomic inventory upserts.

## Production notes

The requested endpoints are implemented, but a genuinely enterprise production system should place them behind a full authentication/authorization service (JWT/OIDC), rate limiting/WAF, centralized logs, secrets management, migrations, automated tests, backups, monitoring, CI/CD, and an HTTPS ingress. The write routes already enforce an owner identity boundary via `x-user-id`; replace that middleware with verified JWT/OIDC claims when integrating your identity provider.
