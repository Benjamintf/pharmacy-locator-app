import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state/locale_state.dart'; import 'screens/search_pharmacy_screen.dart';
void main()=>runApp(ChangeNotifierProvider(create:(_)=>LocaleState(),child:const PharmacyApp()));
class PharmacyApp extends StatelessWidget{const PharmacyApp({super.key});@override Widget build(BuildContext context){final locale=context.watch<LocaleState>().locale;return MaterialApp(debugShowCheckedModeBanner:false,title:'Pharmacy Locator',locale:locale,supportedLocales:const [Locale('en'),Locale('am')],theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.teal,inputDecorationTheme:const InputDecorationTheme(filled:true)),home:const SearchPharmacyScreen());}}
