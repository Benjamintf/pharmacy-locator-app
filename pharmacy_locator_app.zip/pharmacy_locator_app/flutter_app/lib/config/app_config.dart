class AppConfig {
  static const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000/api');
  static const ownerUserId = String.fromEnvironment('OWNER_USER_ID', defaultValue: '');
}
