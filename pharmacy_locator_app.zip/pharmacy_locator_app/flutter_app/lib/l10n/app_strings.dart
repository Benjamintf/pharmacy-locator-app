import 'package:flutter/material.dart';
class AppStrings {
  final Locale locale; AppStrings(this.locale);
  bool get am => locale.languageCode == 'am';
  String t(String en, String amh) => am ? amh : en;
  String get appName => t('Pharmacy Locator','የፋርማሲ መፈለጊያ');
  String get search => t('Search medicine, pharmacy, area or phone','መድሃኒት፣ ፋርማሲ፣ አካባቢ ወይም ስልክ ይፈልጉ');
  String get addPharmacy => t('Add Pharmacy','ፋርማሲ ጨምር');
  String get noResults => t('No results found','ምንም ውጤት አልተገኘም');
  String get retry => t('Retry','እንደገና ሞክር');
  String get pharmacyName => t('Pharmacy name','የፋርማሲ ስም');
  String get phone => t('Phone number','ስልክ ቁጥር');
  String get address => t('Address / Area','አድራሻ / አካባቢ');
  String get open247 => t('Open 24/7','24/7 ክፍት');
  String get hours => t('Operating hours (e.g. 08:00-20:00)','የስራ ሰዓት (ለምሳሌ 08:00-20:00)');
  String get pickMap => t('Pick location on map','ቦታን በካርታ ምረጥ');
  String get medicine => t('Initial medicine name','የመጀመሪያ መድሃኒት ስም');
  String get price => t('Price (ETB)','ዋጋ (ብር)');
  String get quantity => t('Quantity','ብዛት');
  String get save => t('Save pharmacy','ፋርማሲ አስቀምጥ');
  String get selectPoint => t('Tap the map to select a point','ነጥብ ለመምረጥ ካርታውን ይንኩ');
  String get confirm => t('Use this location','ይህን ቦታ ተጠቀም');
  String get required => t('Required','ያስፈልጋል');
  String get created => t('Pharmacy and stock created successfully.','ፋርማሲና ክምችት በተሳካ ሁኔታ ተፈጥረዋል።');
}
