import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';
import '../models/search_result.dart';
class ApiException implements Exception { final String message; ApiException(this.message); @override String toString()=>message; }
class ApiService {
  final http.Client _client; ApiService({http.Client? client}):_client=client??http.Client();
  Future<List<SearchResult>> search(String q) async {
    final uri=Uri.parse('${AppConfig.apiBaseUrl}/medicines/search').replace(queryParameters:{'query':q});
    final r=await _client.get(uri).timeout(const Duration(seconds:12));
    if(r.statusCode!=200) throw ApiException(_message(r));
    return (jsonDecode(r.body) as List).map((e)=>SearchResult.fromJson(e)).toList();
  }
  Future<Map<String,dynamic>> addPharmacy(Map<String,dynamic> body) async {
    _requireOwner(); final r=await _client.post(Uri.parse('${AppConfig.apiBaseUrl}/pharmacies/add'),headers:_headers,body:jsonEncode(body)).timeout(const Duration(seconds:15));
    if(r.statusCode!=201) throw ApiException(_message(r)); return jsonDecode(r.body);
  }
  Future<void> addMedicine(Map<String,dynamic> body) async {
    _requireOwner(); final r=await _client.post(Uri.parse('${AppConfig.apiBaseUrl}/medicines/add'),headers:_headers,body:jsonEncode(body)).timeout(const Duration(seconds:15));
    if(r.statusCode!=201) throw ApiException(_message(r));
  }
  Map<String,String> get _headers=>{'Content-Type':'application/json','x-user-id':AppConfig.ownerUserId};
  void _requireOwner(){if(AppConfig.ownerUserId.isEmpty) throw ApiException('OWNER_USER_ID is not configured.');}
  String _message(http.Response r){try{return (jsonDecode(r.body)['error']??'Request failed (${r.statusCode})').toString();}catch(_){return 'Request failed (${r.statusCode})';}}
}
